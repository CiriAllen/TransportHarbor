import { HttpClient } from '@angular/common/http';
import { Component, inject } from '@angular/core';

@Component({
  selector: 'test-comm',
  templateUrl: './test-comm.component.html',
  styleUrls: ['./test-comm.component.css'],
})
export class TestCommComponent {

  private httpClient = inject(HttpClient);
  ipAddress: string = '';
  port: string = '';
  result: string = '';

  constructor() { }

  testComm() {
    var url = "http://" + this.ipAddress + ":" + this.port + "/comm/test";
    this.httpClient.get(url, { responseType: 'text' }).subscribe({
      next: (response: any) => {
        console.log("test");
        console.log(response);
        this.result = response;
      },
      error: (err) => {
        console.log(err);
        this.result = err.message || '请求失败，请稍后重试';
      }
    });
  }

}
