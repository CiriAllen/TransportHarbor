import { Injectable } from '@angular/core';
@Injectable({
    providedIn: 'root'
})
export class SpeechRecognitionService {

    private recognition: any;

    constructor() {
        const sdk = require("microsoft-cognitiveservices-speech-sdk");
        const speechConfig = sdk.SpeechConfig.fromSubscription("YourSpeechKey", "YourSpeechRegion");
        // Initialize speech recognition engine
    
        this.recognition = new WebSpeechCognitive.SpeechRecognizer(speechConfig);
    }

    async recognizeAudio(audioData: ArrayBuffer): Promise<string> {
        const audioBuffer = await this.bufferToAudioBuffer(audioData);

        return new Promise((resolve, reject) => {
            this.recognition.recognizeOnceAsync((result: any) => {
                resolve(result.text);
            }, (error: any) => {
                reject(error);
            });
        });
    }

    private async bufferToAudioBuffer(buffer: ArrayBuffer): Promise<AudioBuffer> {
        return new Promise((resolve, reject) => {
            const audioContext = new AudioContext();
            audioContext.decodeAudioData(buffer,
                (audioBuffer: AudioBuffer) => resolve(audioBuffer),
                (error: Error) => reject(error));
        });
    }
}