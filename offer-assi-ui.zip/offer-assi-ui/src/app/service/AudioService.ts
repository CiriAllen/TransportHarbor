import { DestroyRef, inject, Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root'
  })
  export class AudioService {
    
    private speakerWebSocket: WebSocket;
    private microphoneWebSocket: WebSocket;
    
    constructor() {
      this.speakerWebSocket = new WebSocket('ws://localhost:9091/speaker');
      this.microphoneWebSocket = new WebSocket('ws://localhost:9091/microphone');
      
      this.setupSpeakerStream();
      this.setupMicrophoneStream();
    }
  
    private setupSpeakerStream() {
      this.speakerWebSocket.onmessage = (event) => {
        const audioData = event.data;
        this.processAudio(audioData, 'speaker');
      };
    }
  
    private setupMicrophoneStream() {
      this.microphoneWebSocket.onmessage = (event) => {
        const audioData = event.data;
        this.processAudio(audioData, 'microphone');
      };
    }
  
    private processAudio(audioData: ArrayBuffer, streamType: string) {
      // Convert audio data to text here
      // Implementation depends on chosen speech recognition service
    }
  }