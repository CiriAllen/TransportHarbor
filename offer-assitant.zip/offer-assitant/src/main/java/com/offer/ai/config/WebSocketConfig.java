package com.offer.ai.config;

import com.offer.ai.handler.AudioWebSocketHandler;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.socket.WebSocketHandler;
import org.springframework.web.socket.config.annotation.EnableWebSocket;
import org.springframework.web.socket.config.annotation.WebSocketConfigurer;
import org.springframework.web.socket.config.annotation.WebSocketHandlerRegistry;

@Configuration
@EnableWebSocket
public class WebSocketConfig implements WebSocketConfigurer {

    @Override
    public void registerWebSocketHandlers(WebSocketHandlerRegistry registry) {
        registry.addHandler(speakerHandler(), "/speaker").setAllowedOrigins("*");
        registry.addHandler(microphoneHandler(), "/microphone").setAllowedOrigins("*");
    }

    @Bean
    public WebSocketHandler speakerHandler() {
        return new AudioWebSocketHandler("speaker");
    }

    @Bean
    public WebSocketHandler microphoneHandler() {
        return new AudioWebSocketHandler("microphone");
    }


}
