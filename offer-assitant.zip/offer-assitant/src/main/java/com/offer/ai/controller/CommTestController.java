package com.offer.ai.controller;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CommTestController {
    @CrossOrigin
    @GetMapping("comm/test")
    public String commTest() {
        System.out.println("request received");
        return "Hello this is your  AI offer assistant!";
    }

}
