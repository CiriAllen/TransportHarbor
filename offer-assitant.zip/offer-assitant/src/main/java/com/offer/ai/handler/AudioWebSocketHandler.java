package com.offer.ai.handler;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.socket.BinaryMessage;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.BinaryWebSocketHandler;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.TargetDataLine;
import java.io.IOException;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArraySet;

public class AudioWebSocketHandler extends BinaryWebSocketHandler {

    private static final Logger logger = LoggerFactory.getLogger(AudioWebSocketHandler.class);

    private final String streamType;
    private static final Map<String, Set<WebSocketSession>> sessions = new ConcurrentHashMap<>();

    public AudioWebSocketHandler(String streamType) {
        this.streamType = streamType;
        sessions.put(streamType, new CopyOnWriteArraySet<>());
    }

    @Override
    public void afterConnectionEstablished(WebSocketSession session) throws Exception {
        sessions.get(streamType).add(session);
        startAudioStreaming(session);
    }

    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus status) throws Exception {
        sessions.get(streamType).remove(session);
    }

    private void startAudioStreaming(WebSocketSession session) {
        new Thread(() -> {
            try {
                // Get audio input based on streamType
                TargetDataLine speakerInput = null;
                TargetDataLine microphoneInput = null;

                if (streamType.equals("speaker")) {
                    speakerInput = AudioSystem.getTargetDataLine(new AudioFormat(
                            8000f, 16, 1, true, false));
                    speakerInput.open();
                    speakerInput.start();
                } else {
                    microphoneInput = AudioSystem.getTargetDataLine(new AudioFormat(
                            8000f, 16, 1, true, false));
                    microphoneInput.open();
                    microphoneInput.start();
                }

                byte[] buffer = new byte[1024];
                while (session.isOpen()) {
                    int bytesRead = streamType.equals("speaker") ?
                            speakerInput.read(buffer, 0, buffer.length) :
                            microphoneInput.read(buffer, 0, buffer.length);

                    if (bytesRead >= 0) {
                        session.sendMessage(new BinaryMessage(buffer, 0, bytesRead,false));
                    }
                    Thread.sleep(10); // Small delay to prevent CPU overload
                }

                if (speakerInput != null) speakerInput.close();
                if (microphoneInput != null) microphoneInput.close();

            } catch (Exception e) {
                logger.error("Error streaming audio", e);
            }
        }).start();
    }

    @Override
    protected void handleBinaryMessage(WebSocketSession session, BinaryMessage binaryMessage)
            throws Exception {
        // Forward message to all connected clients
        sessions.get(streamType).forEach(s -> {
            if (!s.equals(session) && s.isOpen()) {
                try {
                    s.sendMessage(binaryMessage);
                } catch (IOException e) {
                    logger.error("Error forwarding message", e);
                }
            }
        });
    }

}
